GitHub Pages用パッケージです。
1. zipを展開
2. index.html をGitHubリポジトリのルートへアップロード
3. Settings > Pages で Branch: main / Folder: /(root) を選択
4. 数分待って公開URLを開く
